package com.test.automation.exceptions;

public class ExcAssertionsWeb extends AssertionError {

    public static final String COMPARED_TEXT_DOES_NOT_MATCH = "=====> Compared text does not match";

    public ExcAssertionsWeb(String message, Throwable cause) {
        super(message, cause);
    }

    public ExcAssertionsWeb(String message) {
        super(message);
    }

}
