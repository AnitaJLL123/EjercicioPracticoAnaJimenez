package com.test.automation.model.e2eWeb;

import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
public class SingUpModel {
    private String username;
    private String password;
}
