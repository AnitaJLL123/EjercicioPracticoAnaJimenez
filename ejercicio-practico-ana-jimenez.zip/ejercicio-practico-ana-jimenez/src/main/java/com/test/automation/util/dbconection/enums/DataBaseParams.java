package com.test.automation.util.dbconection.enums;

import lombok.Getter;

@Getter
public enum DataBaseParams {

    TYPE,
    USERNAME,
    PASSWORD,
    HOST,
    PORT,
    BASE,
    DATABASE,
    DRIVER_CLASS_NAME("driverClassName"),
    URL;

    private final String paramName;

    DataBaseParams() {
        this.paramName = name().toLowerCase();
    }

    DataBaseParams(String name) {
        this.paramName = name;
    }
}