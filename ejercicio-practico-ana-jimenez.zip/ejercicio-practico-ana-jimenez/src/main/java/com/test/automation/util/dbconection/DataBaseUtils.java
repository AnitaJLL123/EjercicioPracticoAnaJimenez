package com.test.automation.util.dbconection;

import com.test.automation.util.dbconection.enums.DataBaseParams;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import java.util.List;
import java.util.Map;

@Slf4j
public class DataBaseUtils {

    @Getter
    private final JdbcTemplate jdbcTemplate;
    @Getter
    @Setter
    private static Object lastResultAsObject = null;
    @Getter
    @Setter
    private static Map<String, Object> lastResultAsMapStringObject = null;
    @Getter
    @Setter
    private static List<Map<String, Object>> lastResultAsListMapStringObject = null;
    @Getter
    @Setter
    private static int lastExecutionDML;


    public DataBaseUtils(Map<String, Object> config) {
        if ("not_supported".equals(config.get(DataBaseParams.DRIVER_CLASS_NAME.getParamName()))) {
            throw new UnsupportedOperationException();
        } else {
            String url = (String) config.get(DataBaseParams.URL.getParamName());
            String username = (String) config.get(DataBaseParams.USERNAME.getParamName());
            String password = (String) config.get(DataBaseParams.PASSWORD.getParamName());
            String driver = (String) config.get(DataBaseParams.DRIVER_CLASS_NAME.getParamName());
            DriverManagerDataSource dataSource = new DriverManagerDataSource();
            dataSource.setDriverClassName(driver);
            dataSource.setUrl(url);
            dataSource.setUsername(username);
            dataSource.setPassword(password);
            jdbcTemplate = new JdbcTemplate(dataSource);
            log.info("=====> Config jdbcTemplate: " + url);
        }
    }
}