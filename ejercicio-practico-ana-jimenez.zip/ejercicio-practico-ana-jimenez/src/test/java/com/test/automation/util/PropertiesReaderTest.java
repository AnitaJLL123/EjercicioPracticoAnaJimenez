package com.test.automation.util;

import org.junit.Test;

import java.util.Objects;
import java.util.Optional;
import java.util.Properties;

import static com.test.automation.util.constants.Constants.ATTRIB_AZURE_LOCAL_EXECUTION;
import static com.test.automation.util.constants.Constants.PROP_MANUALTEST;
import static org.junit.Assert.assertEquals;

public class PropertiesReaderTest {

    PropertiesReader propertiesReader = new PropertiesReader();
    String nameFileProperties = PROP_MANUALTEST;
    String findPropertie = ATTRIB_AZURE_LOCAL_EXECUTION;
    String expectedValue = "azure";

    @Test
    public void getPropValues() {
        Optional<Properties> opProperties = propertiesReader.getPropValues(nameFileProperties);
        Properties properties;
        if (opProperties.isPresent()) {
            properties = opProperties.get();
            if (Objects.nonNull(properties.get(findPropertie))) {
                assertEquals(expectedValue, properties.get(findPropertie));
            }
        }
    }

    @Test
    public void getProperty() {
        String property = propertiesReader.getProperty(findPropertie, nameFileProperties);
        assertEquals(expectedValue, property);
    }
}