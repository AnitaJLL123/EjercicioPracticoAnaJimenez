package com.test.automation.util.dbconection;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.test.automation.util.dbconection.enums.DataBaseParams;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.stringtemplate.v4.ST;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

@Slf4j
public class MongoUtils {

    @Getter
    private final MongoDatabase database;
    @Getter
    @Setter
    private static MongoCollection lastMongoCollection = null;
    private final Map<String, Object> config;

    public MongoUtils(Map<String, Object> config) {
        this.config = new HashMap<>(config);
        MongoClientSettings clientSettings;
        if (((String) config.get(DataBaseParams.USERNAME.getParamName())).isEmpty()
                || ((String) config.get(DataBaseParams.PASSWORD.getParamName())).isEmpty()
                || ((String) config.get(DataBaseParams.URL.getParamName())).isEmpty()) {
            throw new IllegalArgumentException("=====> Username or Password are null or empty");
        } else {
            clientSettings = getClientSetting(getMongoUrlString(), MongoUtils.getCodec());
        }

        MongoClient mongoClient = MongoClients.create(clientSettings);
        this.database = mongoClient.getDatabase((String) config.get(DataBaseParams.DATABASE.getParamName()));
        log.info("=====> Config Mongo connection");
    }

    private MongoClientSettings getClientSetting(String connString, CodecRegistry codecRegistry) {

        ConnectionString connectionString = new ConnectionString(connString);
        return MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .codecRegistry(codecRegistry)
                .build();
    }

    private static CodecRegistry getCodec() {
        CodecRegistry pojoCodecRegistry = fromProviders(PojoCodecProvider.builder().automatic(true).build());
        return fromRegistries(MongoClientSettings.getDefaultCodecRegistry(), pojoCodecRegistry);
    }

    public String getMongoUrlString() {
        String connectionString;
        String encodedUserName = URLEncoder.encode((String) config.get(DataBaseParams.USERNAME.getParamName()), StandardCharsets.UTF_8);
        String encodedPassword = URLEncoder.encode((String) config.get(DataBaseParams.PASSWORD.getParamName()), StandardCharsets.UTF_8);
        String userinfo = encodedUserName.concat(":").concat(encodedPassword);
        ST stMongoUrl = new ST((String) config.get(DataBaseParams.URL.getParamName()), '{', '}');
        stMongoUrl.add("userinfo", userinfo);
        connectionString = stMongoUrl.render();
        return connectionString;
    }

}