package com.test.automation.util.dbconection;


import com.test.automation.util.PropertiesReader;
import com.test.automation.util.dbconection.enums.DataBaseParams;
import com.test.automation.util.dbconection.enums.DataBaseType;
import org.stringtemplate.v4.ST;

import java.util.*;
import java.util.function.UnaryOperator;

import static com.test.automation.util.constants.Constants.PROP_DATA_BASE;

public class ConfigurationParamUtils {

    private ConfigurationParamUtils() {
    }

    private static final String[] dbConnPipelineParameters = {"<type>_USERNAME", "<type>_PASSWORD", "<type>_HOST", "<type>_PORT", "<type>_BASE"};
    private static final String[] dbConnLocalParameters = {"<type>.username", "<type>.password", "<type>.host", "<type>.port", "<type>.base"};
    private static final String TYPE = DataBaseParams.TYPE.getParamName();
    private static final String USERNAME = DataBaseParams.USERNAME.getParamName();
    private static final String PASSWORD = DataBaseParams.PASSWORD.getParamName();
    private static final String HOST = DataBaseParams.HOST.getParamName();
    private static final String PORT = DataBaseParams.PORT.getParamName();
    private static final String BASE = DataBaseParams.BASE.getParamName();
    private static final String DATABASE = DataBaseParams.DATABASE.getParamName();
    private static final String DRIVER_CLASS_NAME = DataBaseParams.DRIVER_CLASS_NAME.getParamName();
    private static final String URL = DataBaseParams.URL.getParamName();

    public static Map<String, Object> loadEnviromentalValues(String strDatabaseType) {
        Map<String, String> valuesMap;
        DataBaseType dbType = DataBaseType.valueOf(strDatabaseType);
        Optional<Map<String, String>> opValuesEnvMap = createConfigMapEnvParams(dbType);
        Map<String, Object> configMap = new HashMap<>();

        String url;
        if (opValuesEnvMap.isPresent()) {
            valuesMap = normalizeNames(opValuesEnvMap.get(), "_");
        } else {
            PropertiesReader propertiesUtils = new PropertiesReader();
            Optional<Properties> opProperties = propertiesUtils.getPropValues(PROP_DATA_BASE);
            valuesMap = normalizeNames(opProperties
                    .map(properties -> ConfigurationParamUtils.createConfigMapPropertiesParams(properties, dbType))
                    .orElseGet(HashMap::new), "\\.");

        }

        if (checkNulls(valuesMap, dbType)) {
            throw new IllegalArgumentException("=====> Null values for creating the connection to the database");
        } else {
            url = createURL(dbType.getJdbcUrl(), valuesMap.get(HOST),
                    valuesMap.get(PORT), valuesMap.get(BASE));
        }
        configMap.put(USERNAME, valuesMap.get(USERNAME));
        configMap.put(PASSWORD, valuesMap.get(PASSWORD));
        configMap.put(URL, url);
        configMap.put(DRIVER_CLASS_NAME, dbType.getDriver());
        configMap.put(DATABASE, valuesMap.get(BASE));
        return configMap;
    }

    private static Map<String, String> normalizeNames(Map<String, String> stringStringMap, String token) {
        Map<String, String> normalizedNames = new HashMap<>();
        for (Map.Entry<String, String> entry : stringStringMap.entrySet()) {
            String[] splittedValues = entry.getKey().toLowerCase().split(token);
            normalizedNames.put(splittedValues[1], entry.getValue());
        }
        return normalizedNames;
    }

    private static boolean checkNulls(Map<String, String> valuesMap, DataBaseType dbType) {
        if (valuesMap.isEmpty()) {
            return true;
        } else {
            if (dbType.equals(DataBaseType.SQLITE)) {
                return valuesMap.get(HOST) == null || valuesMap.get(BASE) == null;
            } else {
                for (String parameter : valuesMap.values()) {
                    if (Objects.isNull(parameter)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static Optional<Map<String, String>> createConfigMapEnvParams(DataBaseType dbtype) {
        Map<String, String> valuesMap = new HashMap<>();
        String[] finalParameters = getParametersWithDbType(dbConnPipelineParameters, dbtype, value -> value);
        for (String parameter : finalParameters) {

            if (Objects.nonNull(System.getenv(parameter))) {
                valuesMap.put(parameter, System.getenv(parameter));
            } else {
                return Optional.empty();
            }
        }
        return Optional.of(valuesMap);
    }

    private static Map<String, String> createConfigMapPropertiesParams(Properties properties, DataBaseType dbtype) {
        Map<String, String> valuesMap = new HashMap<>();
        String[] finalParameters = getParametersWithDbType(dbConnLocalParameters, dbtype, String::toLowerCase);
        for (String parameter : finalParameters) {
            String value = properties.getProperty(parameter);
            valuesMap.put(parameter, value);
        }
        return valuesMap;
    }

    private static String[] getParametersWithDbType(String[] dbConnParameters, DataBaseType dbtype, UnaryOperator<String> modifier) {
        String[] finalParameters = new String[5];
        for (int i = 0; i < dbConnParameters.length; i++) {
            ST strConfiguration = new ST(dbConnParameters[i]);
            strConfiguration.add(TYPE, modifier.apply(dbtype.name()));
            finalParameters[i] = strConfiguration.render();
        }
        return finalParameters;
    }

    private static String createURL(String urlTemplate, String host, String port, String dbName) {
        ST stUrl = new ST(urlTemplate);
        stUrl.add(HOST, host);
        stUrl.add(PORT, port);
        stUrl.add(DATABASE, dbName);
        return stUrl.render();
    }

}