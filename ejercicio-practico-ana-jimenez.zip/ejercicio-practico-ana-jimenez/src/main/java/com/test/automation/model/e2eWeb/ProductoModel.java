package com.test.automation.model.e2eWeb;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProductoModel {
    private String categoria;
    private String producto;
}
