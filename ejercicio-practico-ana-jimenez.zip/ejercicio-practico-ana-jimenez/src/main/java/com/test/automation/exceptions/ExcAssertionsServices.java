package com.test.automation.exceptions;


public class ExcAssertionsServices extends AssertionError {

    public static final String STATUS_CODE_IS_NOT_EXPECTED = "=====> The statusCode in the response is not what was expected";
    public static final String SCHEME_IS_NOT_AS_EXPECTED = "=====> Response scheme is not as expected";
    public static final String FIELD_VALUE_IS_NOT_WHAT_WAS_EXPECTED = "=====> The field value is not what was expected";


    public ExcAssertionsServices(String message, Throwable cause) {
        super(message, cause);
    }

    public ExcAssertionsServices(String message) {
        super(message);
    }

}
